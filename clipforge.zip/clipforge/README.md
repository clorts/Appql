# ClipForge — editor de vídeo (React + Canvas + FFmpeg.wasm)

## Rodar localmente
    npm install        # o postinstall copia o core do FFmpeg para public/ffmpeg
    npm run dev        # http://localhost:5173
    npm run build      # saída em dist/ (sem sourcemaps)

## Atalhos
Espaço = play/pause · S = cortar no playhead · Delete = apagar clip

## Servidor nativo (opcional, 4K / vídeos longos)
    cd server && docker build -t clipforge-export .
    docker run -p 8000:8000 -e EXPORT_API_KEY=troque -e ALLOWED_ORIGIN=https://editor.seudominio.com clipforge-export

## Desktop (opcional)
Adicione o Tauri (`npm create tauri-app`) e use src-tauri/src/main.rs.

## Publicar no Netlify
1. Suba a pasta para um repositório no GitHub (o .gitignore já exclui node_modules e public/ffmpeg).
2. Netlify → Add new site → Import from Git → escolha o repositório.
3. Build `npm run build`, publish `dist` (o netlify.toml já define isso). Deploy.
