// Copia o core do FFmpeg.wasm para /public (servido da mesma origem => CSP fechada, sem CDN externa)
import { cpSync, mkdirSync, existsSync } from 'node:fs';

const src = 'node_modules/@ffmpeg/core/dist/esm';
const dst = 'public/ffmpeg';
if (!existsSync(src)) { console.warn('@ffmpeg/core não encontrado'); process.exit(0); }
mkdirSync(dst, { recursive: true });
for (const f of ['ffmpeg-core.js', 'ffmpeg-core.wasm']) cpSync(`${src}/${f}`, `${dst}/${f}`);
console.log('FFmpeg core copiado para public/ffmpeg');
