"""Servidor opcional de exportação pesada (4K / vídeos longos) com FFmpeg NATIVO.
Segurança: auth por header, CORS só para a sua origem, limite de tamanho, allowlist de parâmetros,
validação com ffprobe, subprocess SEM shell, pasta temporária isolada e apagada no fim."""
import hmac
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, File, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask

API_KEY = os.environ["EXPORT_API_KEY"]        # falha ao arrancar se não existir
ORIGIN = os.environ["ALLOWED_ORIGIN"]         # ex.: https://editor.seudominio.com
MAX_BYTES = 2 * 1024**3
SIZES = {"1080p": (1920, 1080), "4k": (3840, 2160), "reels": (1080, 1920)}

app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)   # sem /docs público
app.add_middleware(CORSMiddleware, allow_origins=[ORIGIN], allow_methods=["POST"], allow_headers=["X-Api-Key"])


def run(cmd: list[str], timeout: int) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, timeout=timeout, check=False)  # lista, nunca shell=True


def fail(tmp: Path, code: int, msg: str):
    shutil.rmtree(tmp, ignore_errors=True)
    raise HTTPException(status_code=code, detail=msg)


@app.post("/transcode")
async def transcode(
    file: UploadFile = File(...),
    preset: Literal["1080p", "4k", "reels"] = "1080p",
    fps: Literal[30, 60] = 30,
    x_api_key: str = Header(""),
):
    # TROQUE por sessão/JWT em produção: uma chave dentro do JS do navegador não é segredo.
    if not hmac.compare_digest(x_api_key, API_KEY):
        raise HTTPException(status_code=401, detail="não autorizado")

    tmp = Path(tempfile.mkdtemp(prefix="cf_"))
    src, out = tmp / "in.bin", tmp / "out.mp4"
    size = 0
    with src.open("wb") as f:
        while chunk := await file.read(1 << 20):
            size += len(chunk)
            if size > MAX_BYTES:
                f.close(); fail(tmp, 413, "arquivo grande demais")
            f.write(chunk)

    probe = run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                 "stream=codec_type", "-of", "csv=p=0", str(src)], 30)
    if probe.returncode != 0 or b"video" not in probe.stdout:
        fail(tmp, 415, "não é um vídeo válido")

    w, h = SIZES[preset]
    vf = f"scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,format=yuv420p"
    try:
        r = run(["ffmpeg", "-nostdin", "-y", "-i", str(src), "-vf", vf, "-r", str(fps),
                 "-c:v", "libx264", "-preset", "medium", "-crf", "20",
                 "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(out)], 1800)
    except subprocess.TimeoutExpired:
        fail(tmp, 504, "tempo esgotado")
    if r.returncode != 0:
        fail(tmp, 422, "falha na codificação")

    return FileResponse(out, media_type="video/mp4", filename="export.mp4",
                        background=BackgroundTask(shutil.rmtree, tmp, True))
