// Casca desktop opcional (Tauri). Comando nativo de exportação: valida TUDO antes de chamar o FFmpeg.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
use std::{path::PathBuf, process::Command};

#[tauri::command]
fn export_mp4(input: String, output: String, width: u32, height: u32, fps: u32) -> Result<(), String> {
    if !matches!(fps, 24 | 30 | 60) { return Err("fps inválido".into()); }
    if !(16..=3840).contains(&width) || !(16..=3840).contains(&height) { return Err("resolução inválida".into()); }
    let input = PathBuf::from(input).canonicalize().map_err(|e| e.to_string())?;
    let output = PathBuf::from(output);
    if output.extension().and_then(|e| e.to_str()) != Some("mp4") { return Err("a saída deve ser .mp4".into()); }

    let vf = format!(
        "scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,format=yuv420p",
        w = width, h = height
    );
    // Argumentos separados: nunca passa por shell, logo não há injeção de comandos
    let status = Command::new("ffmpeg")
        .args(["-nostdin", "-y", "-i"]).arg(&input)
        .args(["-vf", &vf, "-r", &fps.to_string(), "-c:v", "libx264", "-crf", "20", "-c:a", "aac", "-movflags", "+faststart"])
        .arg(&output)
        .status().map_err(|e| e.to_string())?;
    if status.success() { Ok(()) } else { Err("FFmpeg falhou".into()) }
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![export_mp4])
        .run(tauri::generate_context!())
        .expect("erro ao iniciar a aplicação");
}
