import { useEffect } from 'react';
import { useEditor } from './store/editorStore';
import MediaPool from './components/MediaPool';
import Preview from './components/Preview';
import Properties from './components/Properties';
import ExportPanel from './components/ExportPanel';
import Timeline from './components/Timeline';

export default function App() {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement).tagName;
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(tag)) return;
      const s = useEditor.getState();
      if (e.code === 'Space') { e.preventDefault(); s.setPlaying(!s.playing); }
      else if (e.key === 's' || e.key === 'S') s.splitAtPlayhead();
      else if ((e.key === 'Delete' || e.key === 'Backspace') && s.selectedId) s.removeClip(s.selectedId);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <div className="grid h-full grid-cols-[240px_1fr_280px] grid-rows-[1fr_300px]">
      <aside className="min-h-0 border-b border-r border-zinc-800"><MediaPool /></aside>
      <main className="min-h-0 border-b border-zinc-800"><Preview /></main>
      <aside className="flex min-h-0 flex-col justify-between overflow-y-auto border-b border-l border-zinc-800">
        <Properties /><ExportPanel />
      </aside>
      <section className="col-span-3 min-h-0"><Timeline /></section>
    </div>
  );
}
