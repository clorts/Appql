import { useState } from 'react';
import { useEditor } from '../store/editorStore';
import { exportMp4 } from '../engine/exporter';

const PRESETS: Record<string, [number, number]> = { '1080p (16:9)': [1920, 1080], '4K (16:9)': [3840, 2160], 'Shorts/Reels (9:16)': [1080, 1920] };

export default function ExportPanel() {
  const { project, setFormat } = useEditor();
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [url, setUrl] = useState('');
  const [err, setErr] = useState('');
  const preset = Object.entries(PRESETS).find(([, [w, h]]) => w === project.width && h === project.height)?.[0] ?? '1080p (16:9)';

  const run = async () => {
    setBusy(true); setErr(''); setProgress(0);
    if (url) URL.revokeObjectURL(url);
    try {
      const blob = await exportMp4(project, useEditor.getState().assets, setProgress);
      setUrl(URL.createObjectURL(blob));
    } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  };

  return (
    <div className="space-y-2 border-t border-zinc-800 p-3 text-sm">
      <select className="w-full rounded bg-zinc-900 p-1" value={preset} disabled={busy}
        onChange={e => setFormat(...PRESETS[e.target.value], project.fps)}>
        {Object.keys(PRESETS).map(k => <option key={k}>{k}</option>)}
      </select>
      <select className="w-full rounded bg-zinc-900 p-1" value={project.fps} disabled={busy}
        onChange={e => setFormat(project.width, project.height, +e.target.value)}>
        <option value={30}>30 fps</option><option value={60}>60 fps</option>
      </select>
      {project.width > 1920 && <p className="text-xs text-amber-400">4K no navegador é lento e usa muita memória. Prefira o servidor nativo (server/).</p>}
      <button onClick={run} disabled={busy} className="w-full rounded bg-emerald-600 py-1.5 hover:bg-emerald-500 disabled:opacity-50">
        {busy ? `Exportando… ${(progress * 100).toFixed(0)}%` : 'Exportar MP4'}
      </button>
      {err && <p role="alert" className="text-xs text-red-400">{err}</p>}
      {url && <a href={url} download="video.mp4" className="block text-center text-emerald-400 underline">Baixar video.mp4</a>}
    </div>
  );
}
