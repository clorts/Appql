import { useRef, useState } from 'react';
import { useEditor } from '../store/editorStore';
import { Asset, AssetKind, uid } from '../types/model';

// Allowlist estrita de tipos (SVG fica de fora de propósito) + limite de tamanho
const ALLOWED: Record<string, AssetKind> = {
  'video/mp4': 'video', 'video/webm': 'video', 'video/quicktime': 'video',
  'audio/mpeg': 'audio', 'audio/wav': 'audio', 'audio/ogg': 'audio', 'audio/mp4': 'audio', 'audio/aac': 'audio',
  'image/png': 'image', 'image/jpeg': 'image', 'image/webp': 'image',
};
const MAX_BYTES = 2 * 1024 ** 3;

function probe(file: File, kind: AssetKind, url: string): Promise<Asset> {
  const base = { id: uid(), kind, name: file.name.slice(0, 80), url, file };
  return new Promise((res, rej) => {
    const fail = () => rej(new Error(`Não foi possível ler "${file.name}".`));
    if (kind === 'image') {
      const i = new Image(); i.onload = () => res({ ...base, duration: 0, width: i.naturalWidth, height: i.naturalHeight }); i.onerror = fail; i.src = url;
    } else {
      const m = document.createElement(kind === 'video' ? 'video' : 'audio'); m.preload = 'metadata';
      m.onloadedmetadata = () => res({ ...base, duration: m.duration, width: (m as HTMLVideoElement).videoWidth || 0, height: (m as HTMLVideoElement).videoHeight || 0 });
      m.onerror = fail; m.src = url;
    }
  });
}

export default function MediaPool() {
  const { assets, addAsset, addClipFromAsset, addText } = useEditor();
  const [err, setErr] = useState('');
  const input = useRef<HTMLInputElement>(null);

  const onFiles = async (files: FileList | null) => {
    setErr('');
    for (const f of Array.from(files ?? [])) {
      const kind = ALLOWED[f.type];
      if (!kind) { setErr(`Tipo não permitido: ${f.type || 'desconhecido'}`); continue; }
      if (f.size > MAX_BYTES) { setErr(`"${f.name}" excede 2 GB.`); continue; }
      const url = URL.createObjectURL(f);
      try { addAsset(await probe(f, kind, url)); } catch (e) { URL.revokeObjectURL(url); setErr((e as Error).message); }
    }
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-2 p-3 text-sm">
      <div className="flex gap-2">
        <button onClick={() => input.current?.click()} className="flex-1 rounded bg-sky-600 py-1 hover:bg-sky-500">Importar mídia</button>
        <button onClick={addText} className="rounded bg-zinc-800 px-3 py-1 hover:bg-zinc-700">+ Texto</button>
      </div>
      <input ref={input} type="file" multiple hidden accept={Object.keys(ALLOWED).join(',')} onChange={e => { onFiles(e.target.files); e.target.value = ''; }} />
      {err && <p role="alert" className="text-xs text-red-400">{err}</p>}
      <ul className="min-h-0 flex-1 space-y-1 overflow-y-auto">
        {Object.values(assets).length === 0 && <li className="text-xs text-zinc-500">Importe vídeos, áudios ou imagens para começar.</li>}
        {Object.values(assets).map(a => (
          <li key={a.id} draggable onDragStart={e => e.dataTransfer.setData('text/asset-id', a.id)}
            onDoubleClick={() => addClipFromAsset(a.id)}
            className="cursor-grab truncate rounded bg-zinc-900 px-2 py-1.5 hover:bg-zinc-800" title="Arraste para a timeline ou clique duas vezes">
            {a.name} <span className="text-xs text-zinc-500">{a.kind}{a.duration ? ` · ${a.duration.toFixed(1)}s` : ''}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
