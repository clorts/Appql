import { useEffect, useMemo, useRef } from 'react';
import { useEditor } from '../store/editorStore';
import { MediaManager } from '../engine/media';
import { renderFrame } from '../engine/renderer';
import { fmt, projectDuration } from '../types/model';

export default function Preview() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const media = useMemo(() => new MediaManager(() => useEditor.getState().assets), []);
  const { project, currentTime, playing, setTime, setPlaying } = useEditor();
  const total = projectDuration(project);

  // Loop principal: relógio -> estado -> sincroniza mídia -> desenha. Tudo a cada requestAnimationFrame.
  useEffect(() => {
    let raf = 0, last = performance.now();
    const ctx = canvasRef.current!.getContext('2d')!;
    const loop = (now: number) => {
      const s = useEditor.getState();
      let t = s.currentTime;
      if (s.playing) {
        t += (now - last) / 1000;
        const end = projectDuration(s.project);
        if (t >= end) { t = end; s.setPlaying(false); }
        s.setTime(t);
      }
      last = now;
      media.sync(s.project, t, s.playing);
      renderFrame(ctx, s.project, media, t);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); media.dispose(); };
  }, [media]);

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex min-h-0 flex-1 items-center justify-center bg-black p-2">
        <canvas ref={canvasRef} width={project.width} height={project.height}
          style={{ aspectRatio: `${project.width}/${project.height}`, maxWidth: '100%', maxHeight: '100%' }} />
      </div>
      <div className="flex items-center gap-3 border-t border-zinc-800 px-3 py-2 text-sm">
        <button onClick={() => { if (!playing && currentTime >= total) setTime(0); setPlaying(!playing); }}
          className="w-20 rounded bg-sky-600 py-1 hover:bg-sky-500">{playing ? 'Pausar' : 'Play'}</button>
        <input type="range" className="flex-1" min={0} max={Math.max(total, 0.01)} step={0.01}
          value={Math.min(currentTime, total)} onChange={e => setTime(+e.target.value)} aria-label="Posição" />
        <span className="w-40 text-right font-mono text-xs">{fmt(currentTime)} / {fmt(total)}</span>
        <span className="text-xs text-zinc-400">{project.fps} fps · {project.width}×{project.height}</span>
      </div>
    </div>
  );
}
