import { useEditor } from '../store/editorStore';
import { FONTS } from '../types/model';

function Slider(p: { label: string; value: number; min: number; max: number; step: number; onChange(v: number): void }) {
  return (
    <label className="block text-xs">
      <span className="flex justify-between text-zinc-400"><span>{p.label}</span><span>{p.value.toFixed(2)}</span></span>
      <input type="range" className="w-full" min={p.min} max={p.max} step={p.step} value={p.value} onChange={e => p.onChange(+e.target.value)} />
    </label>
  );
}

export default function Properties() {
  const { project, selectedId, updateClip, updateTransform, updateText } = useEditor();
  const c = selectedId ? project.clips[selectedId] : null;
  if (!c) return <p className="p-3 text-xs text-zinc-500">Selecione um clip na timeline para editar.</p>;
  const t = c.transform;
  return (
    <div className="space-y-3 p-3">
      <Slider label="Opacidade" value={t.opacity} min={0} max={1} step={0.01} onChange={v => updateTransform(c.id, { opacity: v })} />
      <Slider label="Escala" value={t.scale} min={0.1} max={3} step={0.01} onChange={v => updateTransform(c.id, { scale: v })} />
      <Slider label="Posição X" value={t.x} min={0} max={1} step={0.005} onChange={v => updateTransform(c.id, { x: v })} />
      <Slider label="Posição Y" value={t.y} min={0} max={1} step={0.005} onChange={v => updateTransform(c.id, { y: v })} />
      <Slider label="Rotação (°)" value={t.rotation} min={-180} max={180} step={1} onChange={v => updateTransform(c.id, { rotation: v })} />
      {c.assetId && <Slider label="Volume" value={c.volume} min={0} max={1} step={0.01} onChange={v => updateClip(c.id, { volume: v })} />}
      {c.text && (
        <div className="space-y-2 border-t border-zinc-800 pt-3 text-xs">
          <textarea className="w-full rounded bg-zinc-900 p-2" rows={3} maxLength={500} value={c.text.content} onChange={e => updateText(c.id, { content: e.target.value })} />
          <select className="w-full rounded bg-zinc-900 p-1" value={c.text.fontFamily} onChange={e => updateText(c.id, { fontFamily: e.target.value })}>
            {FONTS.map(f => <option key={f}>{f}</option>)}
          </select>
          <div className="flex gap-2">
            <input type="number" className="w-20 rounded bg-zinc-900 p-1" min={8} max={400} value={c.text.fontSize} onChange={e => updateText(c.id, { fontSize: Math.min(400, Math.max(8, +e.target.value || 8)) })} />
            <input type="color" value={c.text.color} onChange={e => updateText(c.id, { color: e.target.value })} aria-label="Cor" />
            <select className="flex-1 rounded bg-zinc-900 p-1" value={c.text.align} onChange={e => updateText(c.id, { align: e.target.value as CanvasTextAlign })}>
              <option value="left">Esquerda</option><option value="center">Centro</option><option value="right">Direita</option>
            </select>
          </div>
        </div>
      )}
    </div>
  );
}
