import { useRef } from 'react';
import { useEditor } from '../store/editorStore';
import { Clip, projectDuration } from '../types/model';

const LABEL_W = 112, RULER_H = 24, ROW_H = 44;
const COLOR = { video: 'bg-sky-700', audio: 'bg-emerald-700', text: 'bg-amber-700' } as const;

export default function Timeline() {
  const { project, assets, zoom, currentTime, selectedId, setTime, select, setZoom, updateClip, toggleMute, addClipFromAsset, splitAtPlayhead, removeClip } = useEditor();
  const inner = useRef<HTMLDivElement>(null);
  const dur = Math.max(30, projectDuration(project) + 10);
  const timeAt = (x: number) => Math.max(0, (x - inner.current!.getBoundingClientRect().left) / zoom);

  const scrub = (e: React.PointerEvent) => {
    const move = (ev: PointerEvent) => setTime(timeAt(ev.clientX));
    move(e.nativeEvent);
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', () => window.removeEventListener('pointermove', move), { once: true });
  };

  // Arrastar clip: mover (corpo), trim esquerdo (l) ou trim direito (r)
  const drag = (e: React.PointerEvent, c: Clip, mode: 'move' | 'l' | 'r') => {
    e.stopPropagation();
    if (project.tracks[c.trackId].locked) return;
    select(c.id);
    const x0 = e.clientX, o = { ...c };
    const a = c.assetId ? assets[c.assetId] : undefined;
    const mediaLen = a && a.kind !== 'image' ? a.duration : Infinity;

    const move = (ev: PointerEvent) => {
      const dt = (ev.clientX - x0) / zoom;
      if (mode === 'move') {
        const rect = inner.current!.getBoundingClientRect();
        const row = project.tracks[project.trackOrder[Math.floor((ev.clientY - rect.top - RULER_H) / ROW_H)]];
        const same = row && row.kind === project.tracks[o.trackId].kind && !row.locked;
        updateClip(o.id, { start: o.start + dt, trackId: same ? row.id : o.trackId });
      } else if (mode === 'l') {
        const d = Math.min(Math.max(dt, -o.offset, -o.start), o.duration - 0.1);
        updateClip(o.id, { start: o.start + d, offset: o.offset + d, duration: o.duration - d });
      } else {
        updateClip(o.id, { duration: Math.min(Math.max(o.duration + dt, 0.1), mediaLen - o.offset) });
      }
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', () => window.removeEventListener('pointermove', move), { once: true });
  };

  const step = zoom < 40 ? 10 : zoom < 100 ? 5 : 1;
  const ticks = Array.from({ length: Math.ceil(dur / step) }, (_, i) => i * step);

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center gap-2 border-b border-zinc-800 px-3 py-1 text-sm">
        <button onClick={splitAtPlayhead} className="rounded bg-zinc-800 px-2 py-1 hover:bg-zinc-700">Cortar (S)</button>
        <button onClick={() => selectedId && removeClip(selectedId)} disabled={!selectedId}
          className="rounded bg-zinc-800 px-2 py-1 hover:bg-zinc-700 disabled:opacity-40">Apagar (Del)</button>
        <span className="ml-auto text-xs text-zinc-400">Zoom</span>
        <input type="range" min={20} max={300} value={zoom} onChange={e => setZoom(+e.target.value)} aria-label="Zoom" />
      </div>

      <div className="flex min-h-0 flex-1 overflow-y-auto">
        <div className="shrink-0 border-r border-zinc-800" style={{ width: LABEL_W, paddingTop: RULER_H }}>
          {project.trackOrder.map(id => (
            <div key={id} style={{ height: ROW_H }} className="flex items-center justify-between border-b border-zinc-800 px-2 text-xs">
              <span>{project.tracks[id].name}</span>
              <button onClick={() => toggleMute(id)} title="Silenciar"
                className={`rounded px-1 ${project.tracks[id].muted ? 'bg-red-700' : 'bg-zinc-800'}`}>M</button>
            </div>
          ))}
        </div>

        <div className="min-w-0 flex-1 overflow-x-auto">
          <div ref={inner} className="relative" style={{ width: dur * zoom, height: RULER_H + ROW_H * project.trackOrder.length }}
            onPointerDown={e => { if (e.target === e.currentTarget) select(null); }}>
            <div className="absolute inset-x-0 top-0 cursor-col-resize border-b border-zinc-800 bg-zinc-900" style={{ height: RULER_H }} onPointerDown={scrub}>
              {ticks.map(s => <span key={s} className="absolute top-1 border-l border-zinc-600 pl-1 text-[10px] text-zinc-400" style={{ left: s * zoom }}>{s}s</span>)}
            </div>

            {project.trackOrder.map((tid, row) => (
              <div key={tid} className="absolute inset-x-0 border-b border-zinc-800"
                style={{ top: RULER_H + row * ROW_H, height: ROW_H }}
                onDragOver={e => e.preventDefault()}
                onDrop={e => { e.preventDefault(); const id = e.dataTransfer.getData('text/asset-id'); if (id) addClipFromAsset(id, tid, timeAt(e.clientX)); }}>
                {Object.values(project.clips).filter(c => c.trackId === tid).map(c => (
                  <div key={c.id} onPointerDown={e => drag(e, c, 'move')}
                    className={`absolute top-1 flex cursor-grab items-center overflow-hidden rounded px-2 text-xs ${COLOR[project.tracks[tid].kind]} ${selectedId === c.id ? 'ring-2 ring-white' : ''}`}
                    style={{ left: c.start * zoom, width: Math.max(6, c.duration * zoom), height: ROW_H - 8 }}>
                    <div className="absolute inset-y-0 left-0 w-1.5 cursor-ew-resize bg-white/40" onPointerDown={e => drag(e, c, 'l')} />
                    <span className="pointer-events-none truncate">{c.text?.content ?? (c.assetId ? assets[c.assetId]?.name : '')}</span>
                    <div className="absolute inset-y-0 right-0 w-1.5 cursor-ew-resize bg-white/40" onPointerDown={e => drag(e, c, 'r')} />
                  </div>
                ))}
              </div>
            ))}

            <div className="pointer-events-none absolute top-0 w-px bg-red-500" style={{ left: currentTime * zoom, height: '100%' }} />
          </div>
        </div>
      </div>
    </div>
  );
}
