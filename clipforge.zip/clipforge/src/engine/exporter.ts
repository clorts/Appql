import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile } from '@ffmpeg/util';
import { Asset, ID, Project, projectDuration } from '../types/model';
import { MediaManager } from './media';
import { renderFrame } from './renderer';

let ffmpeg: FFmpeg | null = null;

async function getFFmpeg() {
  if (ffmpeg) return ffmpeg;
  const f = new FFmpeg();
  // Core servido da MESMA origem (copiado em postinstall) => sem CDN externa, CSP fechada
  await f.load({ coreURL: '/ffmpeg/ffmpeg-core.js', wasmURL: '/ffmpeg/ffmpeg-core.wasm' });
  return (ffmpeg = f);
}

const safeExt = (name: string) => (name.split('.').pop() ?? 'bin').replace(/[^a-z0-9]/gi, '').slice(0, 5) || 'bin';

/**
 * Exportação 100% no cliente:
 *  1) renderiza cada frame do canvas (mesmo renderer do preview) -> JPEG no FS virtual do FFmpeg
 *  2) mixa o áudio de todos os clips (atrim + adelay + volume + amix)
 *  3) codifica H.264 + AAC em MP4
 */
export async function exportMp4(project: Project, assets: Record<ID, Asset>, onProgress?: (p: number) => void): Promise<Blob> {
  const ff = await getFFmpeg();
  const { width, height, fps } = project;
  const dur = projectDuration(project);
  if (dur <= 0) throw new Error('A timeline está vazia.');

  const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  const media = new MediaManager(() => assets, true);
  const total = Math.ceil(dur * fps);
  const written: string[] = [];

  try {
    for (let i = 0; i < total; i++) {
      await media.seek(project, i / fps);
      renderFrame(ctx, project, media, i / fps);
      const blob = await new Promise<Blob>((res, rej) => canvas.toBlob(b => (b ? res(b) : rej(new Error('toBlob falhou'))), 'image/jpeg', 0.92));
      const name = `f${String(i).padStart(6, '0')}.jpg`;
      await ff.writeFile(name, new Uint8Array(await blob.arrayBuffer()));
      written.push(name);
      onProgress?.((i / total) * 0.75);
    }

    // ---- áudio ----
    const aClips = Object.values(project.clips).filter(c => {
      const a = c.assetId ? assets[c.assetId] : null;
      return a && a.kind !== 'image' && !project.tracks[c.trackId].muted && c.volume > 0;
    });
    const inputs: string[] = [];
    for (let i = 0; i < aClips.length; i++) {
      const a = assets[aClips[i].assetId!];
      const fn = `a${i}.${safeExt(a.name)}`;
      await ff.writeFile(fn, await fetchFile(a.file)); written.push(fn);
      inputs.push('-i', fn);
    }
    const filter = aClips.map((c, i) =>
      `[${i + 1}:a]atrim=start=${c.offset}:end=${c.offset + c.duration},asetpts=PTS-STARTPTS,volume=${c.volume},adelay=${Math.round(c.start * 1000)}:all=1[a${i}]`
    ).join(';') + (aClips.length ? `;${aClips.map((_, i) => `[a${i}]`).join('')}amix=inputs=${aClips.length}:normalize=0:dropout_transition=0[aout]` : '');

    const venc = ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p', '-movflags', '+faststart'];
    const base = ['-framerate', String(fps), '-i', 'f%06d.jpg'];
    ff.on('progress', ({ progress }) => onProgress?.(0.75 + Math.min(1, Math.max(0, progress)) * 0.25));

    let code = 1;
    if (aClips.length) {
      code = await ff.exec([...base, ...inputs, '-filter_complex', filter, '-map', '0:v', '-map', '[aout]', ...venc, '-c:a', 'aac', '-b:a', '192k', '-t', String(dur), 'out.mp4']);
    }
    // Sem áudio, ou algum asset sem faixa de áudio (filtro falhou): exporta só vídeo
    if (code !== 0) code = await ff.exec([...base, ...venc, '-an', 'out.mp4']);
    if (code !== 0) throw new Error('FFmpeg falhou ao codificar o MP4.');

    const data = (await ff.readFile('out.mp4')) as Uint8Array;
    written.push('out.mp4');
    onProgress?.(1);
    return new Blob([data as unknown as BlobPart], { type: 'video/mp4' });
  } finally {
    media.dispose();
    for (const f of written) await ff.deleteFile(f).catch(() => {});   // libera memória do wasm
  }
}
