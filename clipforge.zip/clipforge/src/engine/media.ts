import { Asset, Clip, ID, Project } from '../types/model';

type El = HTMLVideoElement | HTMLAudioElement | HTMLImageElement;

/** Um elemento de mídia por CLIP (dois cortes do mesmo vídeo tocam independentes). */
export class MediaManager {
  private els = new Map<ID, El>();
  constructor(private getAssets: () => Record<ID, Asset>, private forceMuted = false) {}

  element(c: Clip): El | null {
    if (!c.assetId) return null;
    const cached = this.els.get(c.id); if (cached) return cached;
    const a = this.getAssets()[c.assetId]; if (!a) return null;
    let el: El;
    if (a.kind === 'image') { el = new Image(); el.src = a.url; }
    else {
      const m = document.createElement(a.kind === 'video' ? 'video' : 'audio');
      m.src = a.url; m.preload = 'auto';
      if (m instanceof HTMLVideoElement) m.playsInline = true;
      el = m;
    }
    this.els.set(c.id, el); return el;
  }

  /** Chamado a cada frame pelo player: liga/desliga/sincroniza o áudio e vídeo. */
  sync(p: Project, t: number, playing: boolean) {
    for (const id of [...this.els.keys()]) if (!p.clips[id]) this.drop(id);
    for (const c of Object.values(p.clips)) {
      const el = this.element(c);
      if (!(el instanceof HTMLMediaElement)) continue;
      const active = t >= c.start && t < c.start + c.duration;
      if (!active) { if (!el.paused) el.pause(); continue; }
      el.muted = this.forceMuted || p.tracks[c.trackId].muted;
      el.volume = Math.min(1, Math.max(0, c.volume));
      const target = c.offset + (t - c.start);
      if (playing) {
        if (Math.abs(el.currentTime - target) > 0.25) el.currentTime = target;
        if (el.paused) el.play().catch(() => {});
      } else {
        if (!el.paused) el.pause();
        if (Math.abs(el.currentTime - target) > 0.03) el.currentTime = target;
      }
    }
  }

  /** Seek exato (usado na exportação frame-a-frame). */
  async seek(p: Project, t: number) {
    const jobs: Promise<void>[] = [];
    for (const c of Object.values(p.clips)) {
      if (!(t >= c.start && t < c.start + c.duration)) continue;
      const el = this.element(c);
      if (!(el instanceof HTMLVideoElement)) continue;
      const target = c.offset + (t - c.start);
      jobs.push(new Promise<void>(res => {
        if (Math.abs(el.currentTime - target) < 0.001 && el.readyState >= 2) return res();
        const done = () => { el.removeEventListener('seeked', done); res(); };
        el.addEventListener('seeked', done);
        el.currentTime = target;
        setTimeout(res, 3000); // nunca trava a exportação
      }));
    }
    await Promise.all(jobs);
  }

  private drop(id: ID) {
    const el = this.els.get(id);
    if (el instanceof HTMLMediaElement) { el.pause(); el.removeAttribute('src'); el.load(); }
    this.els.delete(id);
  }
  dispose() { for (const id of [...this.els.keys()]) this.drop(id); }
}
