import { Project } from '../types/model';
import { MediaManager } from './media';

/** Desenha UM frame do projeto no tempo t. Usado pelo preview E pela exportação (WYSIWYG). */
export function renderFrame(ctx: CanvasRenderingContext2D, p: Project, media: MediaManager, t: number) {
  const W = p.width, H = p.height;
  ctx.globalAlpha = 1; ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);

  for (const trackId of [...p.trackOrder].reverse()) {           // de baixo para cima
    if (p.tracks[trackId].kind === 'audio') continue;
    const clips = Object.values(p.clips).filter(c => c.trackId === trackId && t >= c.start && t < c.start + c.duration);
    for (const c of clips) {
      const tf = c.transform;
      ctx.save();
      ctx.globalAlpha = tf.opacity;
      ctx.translate(tf.x * W, tf.y * H);
      ctx.rotate((tf.rotation * Math.PI) / 180);

      if (c.text) {
        const s = c.text, fs = s.fontSize * tf.scale, lh = fs * 1.2;
        const lines = s.content.split('\n').slice(0, 20);
        ctx.font = `700 ${fs}px "${s.fontFamily}", sans-serif`;
        ctx.fillStyle = s.color; ctx.textAlign = s.align; ctx.textBaseline = 'middle';
        ctx.shadowColor = 'rgba(0,0,0,.6)'; ctx.shadowBlur = fs * 0.08;
        lines.forEach((l, i) => ctx.fillText(l, 0, (i - (lines.length - 1) / 2) * lh));
      } else {
        const el = media.element(c);
        let sw = 0, sh = 0;
        if (el instanceof HTMLVideoElement && el.readyState >= 2) { sw = el.videoWidth; sh = el.videoHeight; }
        else if (el instanceof HTMLImageElement && el.complete) { sw = el.naturalWidth; sh = el.naturalHeight; }
        if (sw && sh && el) {
          const k = Math.min(W / sw, H / sh) * tf.scale;       // "contain" + escala do usuário
          ctx.drawImage(el as CanvasImageSource, (-sw * k) / 2, (-sh * k) / 2, sw * k, sh * k);
        }
      }
      ctx.restore();
    }
  }
}
