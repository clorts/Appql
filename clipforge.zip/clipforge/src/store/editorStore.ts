import { create } from 'zustand';
import { Asset, Clip, ID, Project, TextProps, Transform, createProject, defaultTransform, uid } from '../types/model';

const MIN_DUR = 0.1;

interface State {
  project: Project; assets: Record<ID, Asset>;
  currentTime: number; playing: boolean; selectedId: ID | null; zoom: number; // zoom = px por segundo
  addAsset(a: Asset): void;
  addClipFromAsset(assetId: ID, trackId?: ID, start?: number): void;
  addText(): void;
  updateClip(id: ID, patch: Partial<Clip>): void;
  updateTransform(id: ID, patch: Partial<Transform>): void;
  updateText(id: ID, patch: Partial<TextProps>): void;
  splitAtPlayhead(): void;
  removeClip(id: ID): void;
  toggleMute(trackId: ID): void;
  setFormat(width: number, height: number, fps: number): void;
  setTime(t: number): void; setPlaying(p: boolean): void; select(id: ID | null): void; setZoom(z: number): void;
}

const putClip = (p: Project, c: Clip): Project => ({ ...p, clips: { ...p.clips, [c.id]: c } });

export const useEditor = create<State>((set, get) => ({
  project: createProject(), assets: {}, currentTime: 0, playing: false, selectedId: null, zoom: 80,

  addAsset: a => set(s => ({ assets: { ...s.assets, [a.id]: a } })),

  addClipFromAsset: (assetId, trackId, start) => {
    const s = get(); const a = s.assets[assetId]; if (!a) return;     // valida: id tem de existir
    const kind = a.kind === 'audio' ? 'audio' : 'video';
    const tracks = s.project.trackOrder.map(id => s.project.tracks[id]);
    const track = tracks.find(t => t.id === trackId && t.kind === kind && !t.locked) ?? tracks.find(t => t.kind === kind);
    if (!track) return;
    const clip: Clip = {
      id: uid(), trackId: track.id, assetId, start: Math.max(0, start ?? s.currentTime),
      duration: a.kind === 'image' ? 5 : a.duration, offset: 0, transform: defaultTransform(), volume: 1,
    };
    set({ project: putClip(s.project, clip), selectedId: clip.id });
  },

  addText: () => {
    const s = get(); const track = Object.values(s.project.tracks).find(t => t.kind === 'text'); if (!track) return;
    const clip: Clip = {
      id: uid(), trackId: track.id, assetId: null, start: s.currentTime, duration: 3, offset: 0,
      transform: defaultTransform(), volume: 0,
      text: { content: 'Seu texto', fontFamily: 'Inter', fontSize: 96, color: '#ffffff', align: 'center' },
    };
    set({ project: putClip(s.project, clip), selectedId: clip.id });
  },

  updateClip: (id, patch) => set(s => {
    const c = s.project.clips[id]; if (!c) return s;
    const n = { ...c, ...patch };
    n.start = Math.max(0, n.start); n.duration = Math.max(MIN_DUR, n.duration); n.offset = Math.max(0, n.offset);
    n.volume = Math.min(1, Math.max(0, n.volume));
    return { project: putClip(s.project, n) };
  }),

  updateTransform: (id, patch) => { const c = get().project.clips[id]; if (c) get().updateClip(id, { transform: { ...c.transform, ...patch } }); },
  updateText: (id, patch) => { const c = get().project.clips[id]; if (c?.text) get().updateClip(id, { text: { ...c.text, ...patch } }); },

  splitAtPlayhead: () => {
    const s = get(); const t = s.currentTime;
    const targets = (s.selectedId ? [s.project.clips[s.selectedId]] : Object.values(s.project.clips)).filter(Boolean);
    let p = s.project;
    for (const c of targets) {
      const end = c.start + c.duration;
      if (t - c.start < 0.05 || end - t < 0.05) continue;
      p = putClip(p, { ...c, duration: t - c.start });
      p = putClip(p, { ...c, id: uid(), start: t, offset: c.offset + (t - c.start), duration: end - t });
    }
    set({ project: p });
  },

  removeClip: id => set(s => {
    const { [id]: _, ...rest } = s.project.clips;
    return { project: { ...s.project, clips: rest }, selectedId: s.selectedId === id ? null : s.selectedId };
  }),

  toggleMute: trackId => set(s => ({ project: { ...s.project, tracks: { ...s.project.tracks, [trackId]: { ...s.project.tracks[trackId], muted: !s.project.tracks[trackId].muted } } } })),
  setFormat: (width, height, fps) => set(s => ({ project: { ...s.project, width, height, fps } })),
  setTime: t => set({ currentTime: Math.max(0, t) }),
  setPlaying: playing => set({ playing }),
  select: selectedId => set({ selectedId }),
  setZoom: z => set({ zoom: Math.min(300, Math.max(20, z)) }),
}));
