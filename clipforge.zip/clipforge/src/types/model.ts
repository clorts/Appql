// ===== MODELO DE DADOS =====
// Fonte única de verdade: clips guardam trackId; assets ficam fora do projeto (têm File/Blob, não serializam).
export type ID = string;
export type TrackKind = 'video' | 'audio' | 'text';
export type AssetKind = 'video' | 'audio' | 'image';

export interface Asset {
  id: ID; kind: AssetKind; name: string;
  url: string;            // blob: URL local
  file: File;             // usado pelo FFmpeg na exportação
  duration: number;       // segundos (0 para imagem)
  width: number; height: number;
}

/** x,y normalizados (0..1) = centro do clip no canvas. */
export interface Transform { x: number; y: number; scale: number; rotation: number; opacity: number; }

export interface TextProps {
  content: string; fontFamily: string; fontSize: number; color: string; align: CanvasTextAlign;
}

export interface Clip {
  id: ID; trackId: ID;
  assetId: ID | null;     // null => clip de texto
  start: number;          // posição na timeline (s)
  duration: number;       // duração na timeline (s)
  offset: number;         // ponto de entrada dentro do asset (s)
  transform: Transform;
  volume: number;         // 0..1
  text?: TextProps;
}

export interface Track { id: ID; kind: TrackKind; name: string; muted: boolean; locked: boolean; }

export interface Project {
  name: string; width: number; height: number; fps: number;
  trackOrder: ID[];                 // de cima (desenhada por último) para baixo
  tracks: Record<ID, Track>;
  clips: Record<ID, Clip>;
}

// ===== helpers =====
export const uid = (): ID => crypto.randomUUID();
export const defaultTransform = (): Transform => ({ x: 0.5, y: 0.5, scale: 1, rotation: 0, opacity: 1 });
export const FONTS = ['Inter', 'Arial', 'Georgia', 'Impact', 'Courier New'] as const; // allowlist

export function createProject(): Project {
  const mk = (id: string, kind: TrackKind, name: string): Track => ({ id, kind, name, muted: false, locked: false });
  const tracks = [mk('txt', 'text', 'Texto'), mk('v2', 'video', 'Vídeo 2'), mk('v1', 'video', 'Vídeo 1'), mk('a1', 'audio', 'Áudio 1')];
  return {
    name: 'Projeto sem título', width: 1920, height: 1080, fps: 30,
    trackOrder: tracks.map(t => t.id),
    tracks: Object.fromEntries(tracks.map(t => [t.id, t])),
    clips: {},
  };
}

export const projectDuration = (p: Project) =>
  Object.values(p.clips).reduce((m, c) => Math.max(m, c.start + c.duration), 0);

export function fmt(t: number) {
  const m = Math.floor(t / 60), s = Math.floor(t % 60), f = Math.floor((t % 1) * 100);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(f).padStart(2, '0')}`;
}
